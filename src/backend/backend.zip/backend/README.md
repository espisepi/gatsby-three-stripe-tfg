# Install Lets Encrypt SSL Certificate using Docker, Wordpress and DigitalOcean
This is the source code created during a Video tutorial.

## Youtube Video Link: 
https://youtu.be/lbXc6mKh7U0

In this video tutorial, you would learn that how to install lets encrypt ssl certificate using Docker, Docker-Compose, Wordpress and Digital ocean.




----

Create DigitalOcean account using this link and get $50 FREE: 
https://m.do.co/c/40a4f3245660

Create Payoneer account from this link and earn $25:
https://bit.ly/2HbTXF2
