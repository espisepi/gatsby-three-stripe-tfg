"use strict";

module.exports = {
  fetch: global.fetch
};