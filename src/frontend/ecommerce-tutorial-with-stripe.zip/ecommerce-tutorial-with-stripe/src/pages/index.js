import React from "react"
import Products from "../components/Products/Products"
import "../components/layout.css"

const IndexPage = () => (
  <Products />
)

export default IndexPage
